import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  Button, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  Animated,
  Image,
  Alert,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { MaterialIcons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Stack = createStackNavigator();
const courses = ['Starter', 'Main', 'Dessert', 'Drink'];

const LoginScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);

  useEffect(() => {
    const checkLoggedIn = async () => {
      try {
        const savedUsername = await AsyncStorage.getItem('username');
        const savedPassword = await AsyncStorage.getItem('password');
        
        if (savedUsername && savedPassword) {
          setUsername(savedUsername);
          setPassword(savedPassword);
        }
      } catch (error) {
        console.error('Error loading credentials:', error);
      }
    };
    
    checkLoggedIn();
  }, []);

  const handleAuth = async () => {
    if (!username || !password) {
      Alert.alert('Error', 'Please enter both username and password');
      return;
    }

    setIsLoading(true);
    
    try {
      if (isRegistering) {
        await AsyncStorage.setItem('username', username);
        await AsyncStorage.setItem('password', password);
        Alert.alert('Success', 'Registration successful! Please login.');
        setIsRegistering(false);
      } else {
        const savedUsername = await AsyncStorage.getItem('username');
        const savedPassword = await AsyncStorage.getItem('password');
        
        if (username === savedUsername && password === savedPassword) {
          navigation.replace('Home');
        } else {
          Alert.alert('Login Failed', 'Invalid credentials');
        }
      }
    } catch (error) {
      Alert.alert('Error', 'Something went wrong. Please try again.');
      console.error('Auth error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.loginContainer}
    >
      <ScrollView contentContainerStyle={styles.loginScrollContainer}>
        <Image 
          source={{ uri: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4' }} 
          style={styles.loginImage}
        />
        <Text style={styles.loginTitle}>Restaurant Menu</Text>
        <Text style={styles.loginSubtitle}>
          {isRegistering ? 'Create an account' : 'Please login to continue'}
        </Text>
        
        <TextInput
          style={styles.loginInput}
          placeholder="Username"
          value={username}
          onChangeText={setUsername}
          autoCapitalize="none"
          placeholderTextColor="#999"
        />
        
        <TextInput
          style={styles.loginInput}
          placeholder="Password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          placeholderTextColor="#999"
        />
        
        <TouchableOpacity 
          style={styles.loginButton}
          onPress={handleAuth}
          disabled={isLoading}
        >
          <Text style={styles.loginButtonText}>
            {isLoading ? 'Processing...' : isRegistering ? 'Register' : 'Login'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.toggleAuthButton}
          onPress={() => setIsRegistering(!isRegistering)}
        >
          <Text style={styles.toggleAuthText}>
            {isRegistering ? 'Already have an account? Login' : 'Need an account? Register'}
          </Text>
        </TouchableOpacity>

        {!isRegistering && (
          <Text style={styles.loginHint}>
            Your saved credentials will be used automatically
          </Text>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const HomeScreen = ({ navigation, menuItems, addMenuItem }) => {
  const [animation] = useState(new Animated.Value(1));
  const [showMenu, setShowMenu] = useState(false);

  const animateButton = () => {
    Animated.sequence([
      Animated.timing(animation, {
        toValue: 1.2,
        duration: 100,
        useNativeDriver: true
      }),
      Animated.timing(animation, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true
      })
    ]).start();
  };

  const handleAddSampleItems = () => {
    animateButton();
    const sampleItems = [
      {
        id: Math.random().toString(),
        name: 'Bruschetta',
        description: 'Toasted bread topped with tomatoes, garlic, and fresh basil',
        course: 'Starter',
        price: '85.99'
      },
      {
        id: Math.random().toString(),
        name: 'Margherita Pizza',
        description: 'Classic pizza with tomato sauce, mozzarella, and basil',
        course: 'Main',
        price: '149.99'
      },
      {
        id: Math.random().toString(),
        name: 'Tiramisu',
        description: 'Coffee-flavored Italian dessert with layers of ladyfingers and mascarpone',
        course: 'Dessert',
        price: '79.99'
      },
      {
        id: Math.random().toString(),
        name: 'Sparkling Water',
        description: 'Natural mineral water with bubbles',
        course: 'Drink',
        price: '25.50'
      }
    ];
    
    sampleItems.forEach(item => addMenuItem(item));
    Alert.alert(
      'Success',
      `${sampleItems.length} sample items added to the menu!`,
      [{ text: 'OK' }]
    );
  };

  const animatedStyle = {
    transform: [{ scale: animation }]
  };

  return (
    <View style={styles.container}>
      <Image 
        source={{ uri: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4' }} 
        style={styles.headerImage}
      />
      <Text style={styles.title}>Restaurant Menu</Text>
      <Text style={styles.subtitle}>Total items: {menuItems.length}</Text>
      
      <Animated.View style={[styles.animatedButton, animatedStyle]}>
        <Button 
          title="Add Sample Menu Items" 
          onPress={handleAddSampleItems}
          color="black"
        />
      </Animated.View>
      
      <TouchableOpacity 
        style={styles.addButton}
        onPress={() => navigation.navigate('AddItem')}
      >
        <Text style={styles.addButtonText}>+ Add New Item</Text>
      </TouchableOpacity>
      
      <ScrollView 
        style={styles.menuScrollContainer}
        contentContainerStyle={styles.menuScrollContent}
        showsVerticalScrollIndicator={true}
      >
        {menuItems.length === 0 ? (
          <Text style={styles.emptyMessage}>No menu items yet. Add some!</Text>
        ) : (
          menuItems.map((item) => (
            <View key={item.id} style={styles.menuItem}>
              <Text style={styles.menuItemName}>{item.name}</Text>
              <Text style={styles.menuItemCourse}>{item.course}</Text>
              <Text style={styles.menuItemDescription}>{item.description}</Text>
              <Text style={styles.menuItemPrice}>R{item.price}</Text>
            </View>
          ))
        )}
      </ScrollView>

      {showMenu && (
        <View style={styles.menuDropdown}>
          <TouchableOpacity 
            style={styles.menuItemButton}
            onPress={() => {
              setShowMenu(false);
              navigation.navigate('Home');
            }}
          >
            <Text style={styles.menuItemText}>Home</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.menuItemButton}
            onPress={() => {
              setShowMenu(false);
              navigation.navigate('AddItem');
            }}
          >
            <Text style={styles.menuItemText}>Add Item</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
};

const AddItemScreen = ({ navigation, addMenuItem }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [selectedCourse, setSelectedCourse] = useState('');
  const [price, setPrice] = useState('');
  const [animation] = useState(new Animated.Value(1));

  const animateButton = () => {
    Animated.sequence([
      Animated.timing(animation, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true
      }),
      Animated.timing(animation, {
        toValue: 1.05,
        duration: 100,
        useNativeDriver: true
      }),
      Animated.timing(animation, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true
      })
    ]).start();
  };

  const handleSubmit = () => {
    if (!name || !description || !selectedCourse || !price) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }

    animateButton();
    
    const newItem = {
      id: Math.random().toString(),
      name,
      description,
      course: selectedCourse,
      price
    };

    addMenuItem(newItem);
    setName('');
    setDescription('');
    setSelectedCourse('');
    setPrice('');
    navigation.navigate('Home');
  };

  const animatedStyle = {
    transform: [{ scale: animation }]
  };

  return (
    <ScrollView 
      style={styles.container}
      contentContainerStyle={styles.addItemContentContainer}
    >
      <Text style={styles.formTitle}>Add New Menu Item</Text>
      
      <Text style={styles.label}>Dish name</Text>
      <TextInput
        style={styles.input}
        value={name}
        onChangeText={setName}
        placeholder="Enter dish name"
      />
      
      <Text style={styles.label}>Description</Text>
      <TextInput
        style={[styles.input, styles.multilineInput]}
        value={description}
        onChangeText={setDescription}
        placeholder="Enter description"
        multiline
      />
      
      <Text style={styles.label}>Course</Text>
      <View style={styles.courseContainer}>
        {courses.map((course) => (
          <TouchableOpacity
            key={course}
            style={[
              styles.courseButton,
              selectedCourse === course && styles.selectedCourseButton
            ]}
            onPress={() => setSelectedCourse(course)}
          >
            <Text style={selectedCourse === course ? styles.selectedCourseText : styles.courseText}>
              {course}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
      
      <Text style={styles.label}>Price (R)</Text>
      <TextInput
        style={styles.input}
        value={price}
        onChangeText={setPrice}
        placeholder="Enter price in Rand"
        keyboardType="decimal-pad"
      />
      
      <Animated.View style={[styles.submitButton, animatedStyle]}>
        <Button 
          title="Add to Menu" 
          onPress={handleSubmit}
          color="black"
        />
      </Animated.View>
    </ScrollView>
  );
};

const App = () => {
  const [menuItems, setMenuItems] = useState([]);

  const addMenuItem = (item) => {
    setMenuItems(prevItems => [...prevItems, item]);
  };

  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen 
          name="Login" 
          component={LoginScreen} 
          options={{ headerShown: false }}
        />
        <Stack.Screen 
          name="Home"
          options={({ navigation }) => ({
            headerRight: () => (
              <TouchableOpacity 
                style={styles.menuIconContainer}
                onPress={() => navigation.setParams({ showMenu: true })}
              >
                <MaterialIcons name="menu" size={24} color="black" />
              </TouchableOpacity>
            ),
          })}
        >
          {(props) => <HomeScreen {...props} menuItems={menuItems} addMenuItem={addMenuItem} />}
        </Stack.Screen>
        <Stack.Screen 
          name="AddItem"
          options={({ navigation }) => ({
            headerRight: () => (
              <TouchableOpacity 
                style={styles.menuIconContainer}
                onPress={() => navigation.setParams({ showMenu: true })}
              >
                <MaterialIcons name="menu" size={24} color="black" />
              </TouchableOpacity>
            ),
          })}
        >
          {(props) => <AddItemScreen {...props} addMenuItem={addMenuItem} />}
        </Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#FFFF00',
  },
  headerImage: {
    width: '100%',
    height: 150,
    borderRadius: 10,
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginBottom: 20,
    textAlign: 'center',
  },
  menuScrollContainer: {
    flex: 1,
    width: '100%',
    marginTop: 10,
  },
  menuScrollContent: {
    paddingBottom: 30,
  },
  addItemContentContainer: {
    paddingBottom: 40,
  },
  menuItem: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    width: '100%',
  },
  menuItemName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  menuItemCourse: {
    fontSize: 14,
    color: '#000000',
    marginTop: 5,
  },
  menuItemDescription: {
    fontSize: 14,
    color: '#666',
    marginTop: 8,
    lineHeight: 20,
  },
  menuItemPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000000',
    marginTop: 10,
    textAlign: 'right',
  },
  emptyMessage: {
    textAlign: 'center',
    color: '#999',
    fontSize: 16,
    marginTop: 50,
  },
  addButton: {
    backgroundColor: '#000000',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 20,
  },
  addButtonText: {
    color: '#FFFF00',
    fontSize: 16,
    fontWeight: 'bold',
  },
  formTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 20,
    textAlign: 'center',
  },
  label: {
    fontSize: 16,
    color: '#333',
    marginBottom: 8,
    fontWeight: '500',
  },
  input: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#ddd',
    fontSize: 16,
  },
  multilineInput: {
    minHeight: 100,
    textAlignVertical: 'top',
  },
  courseContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 20,
    justifyContent: 'space-between',
  },
  courseButton: {
    padding: 12,
    borderRadius: 8,
    backgroundColor: '#f0f0f0',
    marginBottom: 10,
    width: '48%',
    alignItems: 'center',
  },
  selectedCourseButton: {
    backgroundColor: '#000000',
  },
  courseText: {
    color: '#333',
  },
  selectedCourseText: {
    color: '#FFFF00',
    fontWeight: 'bold',
  },
  submitButton: {
    marginTop: 20,
    marginBottom: 40,
  },
  animatedButton: {
    marginBottom: 20,
  },
  menuIconContainer: {
    marginRight: 15,
  },
  menuDropdown: {
    position: 'absolute',
    top: 60,
    right: 20,
    backgroundColor: '#FFFF00',
    borderRadius: 8,
    padding: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
    zIndex: 100,
    borderWidth: 1,
    borderColor: '#000000'
  },
  menuItemButton: {
    paddingVertical: 10,
    paddingHorizontal: 15,
  },
  menuItemText: {
    fontSize: 16,
    color: '#000000',
  },
  loginContainer: {
    flex: 1,
    backgroundColor: '#FFFF00',
  },
  loginScrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
  },
  loginImage: {
    width: '100%',
    height: 200,
    borderRadius: 10,
    marginBottom: 30,
  },
  loginTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
    textAlign: 'center',
  },
  loginSubtitle: {
    fontSize: 16,
    color: '#666',
    marginBottom: 30,
    textAlign: 'center',
  },
  loginInput: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#ddd',
    fontSize: 16,
    color: '#333',
  },
  loginButton: {
    backgroundColor: '#000000',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10,
  },
  loginButtonText: {
    color: '#FFFF00',
    fontSize: 16,
    fontWeight: 'bold',
  },
  loginHint: {
    marginTop: 20,
    color: '#999',
    textAlign: 'center',
    fontStyle: 'italic',
  },
  toggleAuthButton: {
    marginTop: 15,
    padding: 10,
    alignItems: 'center',
  },
  toggleAuthText: {
    color: '#000000',
    fontSize: 14,
    textDecorationLine: 'underline',
  },
});

export default App;