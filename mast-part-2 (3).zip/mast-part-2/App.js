import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  TouchableWithoutFeedback,
  Animated,
  Image,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Modal,
  FlatList
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { MaterialIcons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Stack = createStackNavigator();
const courses = ['Starter', 'Main', 'Dessert', 'Drink'];

const LoginScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);

  useEffect(() => {
    const checkLoggedIn = async () => {
      try {
        const savedUsername = await AsyncStorage.getItem('username');
        const savedPassword = await AsyncStorage.getItem('password');
        
        if (savedUsername && savedPassword) {
          navigation.replace('Home');
        }
      } catch (error) {
        console.error('Error loading credentials:', error);
      }
    };
    
    checkLoggedIn();
  }, []);

  const handleAuth = async () => {
    if (!username || !password) {
      Alert.alert('Error', 'Please enter both username and password');
      return;
    }

    setIsLoading(true);
    
    try {
      if (isRegistering) {
        await AsyncStorage.setItem('username', username);
        await AsyncStorage.setItem('password', password);
        Alert.alert('Success', 'Registration successful! Please login.');
        setIsRegistering(false);
      } else {
        const savedUsername = await AsyncStorage.getItem('username');
        const savedPassword = await AsyncStorage.getItem('password');
        
        if (username === savedUsername && password === savedPassword) {
          navigation.replace('Home');
        } else {
          Alert.alert('Login Failed', 'Invalid credentials');
        }
      }
    } catch (error) {
      Alert.alert('Error', 'Something went wrong. Please try again.');
      console.error('Auth error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.loginContainer}
    >
      <ScrollView contentContainerStyle={styles.loginScrollContainer}>
        <Image 
          source={{ uri: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4' }} 
          style={styles.loginImage}
        />
        <Text style={styles.loginTitle}>Restaurant Menu</Text>
        <Text style={styles.loginSubtitle}>
          {isRegistering ? 'Create an account' : 'Please login to continue'}
        </Text>
        
        <TextInput
          style={styles.loginInput}
          placeholder="Username"
          value={username}
          onChangeText={setUsername}
          autoCapitalize="none"
          placeholderTextColor="#999"
        />
        
        <TextInput
          style={styles.loginInput}
          placeholder="Password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          placeholderTextColor="#999"
        />
        
        <TouchableOpacity 
          style={styles.loginButton}
          onPress={handleAuth}
          disabled={isLoading}
        >
          <Text style={styles.loginButtonText}>
            {isLoading ? 'Processing...' : isRegistering ? 'Register' : 'Login'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.toggleAuthButton}
          onPress={() => setIsRegistering(!isRegistering)}
        >
          <Text style={styles.toggleAuthText}>
            {isRegistering ? 'Already have an account? Login' : 'Need an account? Register'}
          </Text>
        </TouchableOpacity>

        {!isRegistering && (
          <Text style={styles.loginHint}>
            Your saved credentials will be used automatically
          </Text>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const HomeScreen = ({ navigation, route }) => {
  const [menuItems, setMenuItems] = useState([]);
  const [showMenu, setShowMenu] = useState(false);
  const [filterModalVisible, setFilterModalVisible] = useState(false);
  const [filteredCourse, setFilteredCourse] = useState(null);
  const menuAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loadMenuItems = async () => {
      try {
        const savedItems = await AsyncStorage.getItem('menuItems');
        if (savedItems) {
          setMenuItems(JSON.parse(savedItems));
        }
      } catch (error) {
        console.error('Error loading menu items:', error);
      }
    };

    const unsubscribe = navigation.addListener('focus', loadMenuItems);
    return unsubscribe;
  }, [navigation]);

  const toggleMenu = () => {
    if (showMenu) {
      Animated.timing(menuAnim, {
        toValue: 0,
        duration: 200,
        useNativeDriver: true,
      }).start(() => setShowMenu(false));
    } else {
      setShowMenu(true);
      Animated.timing(menuAnim, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }).start();
    }
  };

  const calculateAveragePrices = () => {
    const courseStats = {};
    
    courses.forEach(course => {
      const items = menuItems.filter(item => item.course === course);
      if (items.length > 0) {
        const total = items.reduce((sum, item) => sum + parseFloat(item.price), 0);
        courseStats[course] = (total / items.length).toFixed(2);
      } else {
        courseStats[course] = '0.00';
      }
    });
    
    return courseStats;
  };

  const addToMyMenu = async (item) => {
    try {
      const savedMenu = await AsyncStorage.getItem('myMenuItems');
      const currentMenu = savedMenu ? JSON.parse(savedMenu) : [];
      
      if (currentMenu.some(menuItem => menuItem.id === item.id)) {
        Alert.alert('Info', 'This item is already in your menu');
        return;
      }
      
      const updatedMenu = [...currentMenu, item];
      await AsyncStorage.setItem('myMenuItems', JSON.stringify(updatedMenu));
      Alert.alert('Success', 'Item added to your menu!');
    } catch (error) {
      console.error('Error adding to menu:', error);
      Alert.alert('Error', 'Failed to add item to menu');
    }
  };

  const averagePrices = calculateAveragePrices();
  const filteredItems = filteredCourse 
    ? menuItems.filter(item => item.course === filteredCourse)
    : menuItems;

  return (
    <View style={styles.container}>
      <Image 
        source={{ uri: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4' }} 
        style={styles.headerImage}
      />
      <Text style={styles.title}>Restaurant Menu</Text>
      <Text style={styles.subtitle}>Total items: {menuItems.length}</Text>
      
      <View style={styles.averagePricesContainer}>
        <Text style={styles.averagePricesTitle}>Average Prices by Course:</Text>
        {courses.map(course => (
          <View key={course} style={styles.averagePriceRow}>
            <Text style={styles.averagePriceCourse}>{course}:</Text>
            <Text style={styles.averagePriceValue}>R{averagePrices[course]}</Text>
          </View>
        ))}
      </View>
      
      <View style={styles.filterButtonsContainer}>
        <TouchableOpacity
          style={styles.filterButton}
          onPress={() => setFilterModalVisible(true)}
        >
          <Text style={styles.filterButtonText}>
            {filteredCourse ? `Filter: ${filteredCourse}` : 'Filter by Course'}
          </Text>
        </TouchableOpacity>
        
        {filteredCourse && (
          <TouchableOpacity
            style={styles.clearFilterButton}
            onPress={() => setFilteredCourse(null)}
          >
            <Text style={styles.clearFilterButtonText}>Clear Filter</Text>
          </TouchableOpacity>
        )}
      </View>
      
      <ScrollView 
        style={styles.menuScrollContainer}
        contentContainerStyle={styles.menuScrollContent}
      >
        {filteredItems.length === 0 ? (
          <Text style={styles.emptyMessage}>
            {filteredCourse ? `No ${filteredCourse} items` : 'No menu items yet'}
          </Text>
        ) : (
          filteredItems.map((item) => (
            <View key={item.id} style={styles.menuItemContainer}>
              <TouchableOpacity 
                style={styles.menuItem}
                onPress={() => navigation.navigate('MenuItemDetail', { item })}
              >
                <Text style={styles.menuItemName}>{item.name}</Text>
                <Text style={styles.menuItemCourse}>{item.course}</Text>
                <Text style={styles.menuItemDescription}>{item.description}</Text>
                <Text style={styles.menuItemPrice}>R{item.price}</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.addToMenuButton}
                onPress={() => addToMyMenu(item)}
              >
                <Text style={styles.addToMenuButtonText}>Add to My Menu</Text>
              </TouchableOpacity>
            </View>
          ))
        )}
      </ScrollView>

      <Modal
        animationType="slide"
        transparent={true}
        visible={filterModalVisible}
        onRequestClose={() => setFilterModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Filter by Course</Text>
            {courses.map(course => (
              <TouchableOpacity
                key={course}
                style={styles.modalFilterOption}
                onPress={() => {
                  setFilteredCourse(course);
                  setFilterModalVisible(false);
                }}
              >
                <Text style={styles.modalFilterText}>{course}</Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity
              style={styles.modalCloseButton}
              onPress={() => setFilterModalVisible(false)}
            >
              <Text style={styles.modalCloseText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {showMenu && (
        <TouchableWithoutFeedback onPress={toggleMenu}>
          <View style={styles.menuOverlay} />
        </TouchableWithoutFeedback>
      )}

      {showMenu && (
        <Animated.View 
          style={[
            styles.menuDropdown,
            {
              opacity: menuAnim,
              transform: [{
                scale: menuAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0.8, 1]
                })
              }]
            }
          ]}
        >
          <TouchableOpacity 
            style={styles.menuItemButton}
            onPress={() => {
              toggleMenu();
              navigation.navigate('Home');
            }}
          >
            <MaterialIcons name="home" size={20} color="#000" />
            <Text style={styles.menuItemText}>Home</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.menuItemButton}
            onPress={() => {
              toggleMenu();
              navigation.navigate('ManageMenu');
            }}
          >
            <MaterialIcons name="restaurant-menu" size={20} color="#000" />
            <Text style={styles.menuItemText}>Manage Menu</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.menuItemButton}
            onPress={() => {
              toggleMenu();
              navigation.navigate('MyMenu');
            }}
          >
            <MaterialIcons name="list-alt" size={20} color="#000" />
            <Text style={styles.menuItemText}>My Menu</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.menuItemButton}
            onPress={async () => {
              toggleMenu();
              await AsyncStorage.clear();
              navigation.replace('Login');
            }}
          >
            <MaterialIcons name="logout" size={20} color="#000" />
            <Text style={styles.menuItemText}>Logout</Text>
          </TouchableOpacity>
        </Animated.View>
      )}

      <TouchableOpacity
        style={styles.menuButton}
        onPress={toggleMenu}
        hitSlop={{ top: 20, bottom: 20, left: 20, right: 20 }}
      >
        <MaterialIcons name="menu" size={30} color="black" />
      </TouchableOpacity>
    </View>
  );
};

const MyMenuScreen = ({ navigation }) => {
  const [myMenuItems, setMyMenuItems] = useState([]);

  useEffect(() => {
    const loadMyMenu = async () => {
      try {
        const savedMenu = await AsyncStorage.getItem('myMenuItems');
        if (savedMenu) {
          setMyMenuItems(JSON.parse(savedMenu));
        }
      } catch (error) {
        console.error('Error loading my menu:', error);
      }
    };

    const unsubscribe = navigation.addListener('focus', loadMyMenu);
    return unsubscribe;
  }, [navigation]);

  const removeFromMenu = async (id) => {
    try {
      const updatedMenu = myMenuItems.filter(item => item.id !== id);
      setMyMenuItems(updatedMenu);
      await AsyncStorage.setItem('myMenuItems', JSON.stringify(updatedMenu));
      Alert.alert('Success', 'Item removed from your menu');
    } catch (error) {
      console.error('Error removing from menu:', error);
      Alert.alert('Error', 'Failed to remove item');
    }
  };

  const calculateTotal = () => {
    return myMenuItems.reduce((sum, item) => sum + parseFloat(item.price), 0).toFixed(2);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>My Menu</Text>
      <Text style={styles.subtitle}>Total items: {myMenuItems.length}</Text>
      
      {myMenuItems.length > 0 && (
        <View style={styles.totalContainer}>
          <Text style={styles.totalText}>Total: R{calculateTotal()}</Text>
        </View>
      )}
      
      {myMenuItems.length === 0 ? (
        <Text style={styles.emptyMessage}>Your menu is empty. Add items from the main menu!</Text>
      ) : (
        <FlatList
          data={myMenuItems}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.myMenuItem}>
              <View style={styles.myMenuItemInfo}>
                <Text style={styles.myMenuItemName}>{item.name}</Text>
                <Text style={styles.myMenuItemCourse}>{item.course}</Text>
                <Text style={styles.myMenuItemPrice}>R{item.price}</Text>
              </View>
              <TouchableOpacity 
                style={styles.removeButton}
                onPress={() => removeFromMenu(item.id)}
              >
                <MaterialIcons name="remove-circle" size={24} color="#ff4444" />
              </TouchableOpacity>
            </View>
          )}
        />
      )}
    </View>
  );
};

const MenuItemDetailScreen = ({ route }) => {
  const { item } = route.params;
  
  return (
    <View style={styles.detailContainer}>
      <Text style={styles.detailTitle}>{item.name}</Text>
      <Text style={styles.detailCourse}>{item.course}</Text>
      <Text style={styles.detailDescription}>{item.description}</Text>
      <Text style={styles.detailPrice}>R{item.price}</Text>
    </View>
  );
};

const ManageMenuScreen = ({ navigation }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [selectedCourse, setSelectedCourse] = useState('');
  const [price, setPrice] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [currentId, setCurrentId] = useState(null);
  const [menuItems, setMenuItems] = useState([]);

  useEffect(() => {
    const loadMenuItems = async () => {
      try {
        const savedItems = await AsyncStorage.getItem('menuItems');
        if (savedItems) {
          setMenuItems(JSON.parse(savedItems));
        }
      } catch (error) {
        console.error('Error loading menu items:', error);
      }
    };

    loadMenuItems();
  }, []);

  useEffect(() => {
    const saveMenuItems = async () => {
      try {
        await AsyncStorage.setItem('menuItems', JSON.stringify(menuItems));
      } catch (error) {
        console.error('Error saving menu items:', error);
      }
    };

    saveMenuItems();
  }, [menuItems]);

  const handleSubmit = () => {
    if (!name || !description || !selectedCourse || !price) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }
    
    const newItem = {
      id: isEditing ? currentId : Math.random().toString(),
      name,
      description,
      course: selectedCourse,
      price
    };

    if (isEditing) {
      setMenuItems(prevItems => 
        prevItems.map(item => item.id === currentId ? newItem : item)
      );
    } else {
      setMenuItems(prevItems => [...prevItems, newItem]);
    }
    
    setName('');
    setDescription('');
    setSelectedCourse('');
    setPrice('');
    setIsEditing(false);
    setCurrentId(null);
  };

  const handleEdit = (item) => {
    setName(item.name);
    setDescription(item.description);
    setSelectedCourse(item.course);
    setPrice(item.price);
    setCurrentId(item.id);
    setIsEditing(true);
  };

  const handleDelete = (id) => {
    Alert.alert(
      'Delete Item',
      'Are you sure you want to delete this menu item?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete', 
          style: 'destructive',
          onPress: () => {
            setMenuItems(prevItems => prevItems.filter(item => item.id !== id));
          }
        }
      ]
    );
  };

  return (
    <View style={styles.manageContainer}>
      <ScrollView style={styles.manageFormContainer}>
        <Text style={styles.formTitle}>
          {isEditing ? 'Edit Menu Item' : 'Add New Menu Item'}
        </Text>
        
        <Text style={styles.label}>Dish name</Text>
        <TextInput
          style={styles.input}
          value={name}
          onChangeText={setName}
          placeholder="Enter dish name"
        />
        
        <Text style={styles.label}>Description</Text>
        <TextInput
          style={[styles.input, styles.multilineInput]}
          value={description}
          onChangeText={setDescription}
          placeholder="Enter description"
          multiline
        />
        
        <Text style={styles.label}>Course</Text>
        <View style={styles.courseContainer}>
          {courses.map((course) => (
            <TouchableOpacity
              key={course}
              style={[
                styles.courseButton,
                selectedCourse === course && styles.selectedCourseButton
              ]}
              onPress={() => setSelectedCourse(course)}
            >
              <Text style={selectedCourse === course ? styles.selectedCourseText : styles.courseText}>
                {course}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
        
        <Text style={styles.label}>Price (R)</Text>
        <TextInput
          style={styles.input}
          value={price}
          onChangeText={setPrice}
          placeholder="Enter price in Rand"
          keyboardType="decimal-pad"
        />
        
        <TouchableOpacity 
          style={styles.submitButtonContainer}
          onPress={handleSubmit}
        >
          <Text style={styles.submitButtonText}>
            {isEditing ? 'Update Item' : 'Add to Menu'}
          </Text>
        </TouchableOpacity>
      </ScrollView>

      <View style={styles.menuListContainer}>
        <Text style={styles.currentMenuTitle}>Current Menu Items ({menuItems.length})</Text>
        <FlatList
          data={menuItems}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.manageMenuItem}>
              <View style={styles.manageMenuItemInfo}>
                <Text style={styles.manageMenuItemName}>{item.name}</Text>
                <Text style={styles.manageMenuItemCourse}>{item.course}</Text>
                <Text style={styles.manageMenuItemPrice}>R{item.price}</Text>
              </View>
              <View style={styles.manageMenuItemActions}>
                <TouchableOpacity 
                  style={styles.editButton}
                  onPress={() => handleEdit(item)}
                >
                  <MaterialIcons name="edit" size={20} color="white" />
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.deleteButton}
                  onPress={() => handleDelete(item.id)}
                >
                  <MaterialIcons name="delete" size={20} color="white" />
                </TouchableOpacity>
              </View>
            </View>
          )}
          ListEmptyComponent={
            <Text style={styles.emptyMessage}>No menu items yet. Add some!</Text>
          }
        />
      </View>
    </View>
  );
};

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen 
          name="Login" 
          component={LoginScreen} 
          options={{ headerShown: false }}
        />
        <Stack.Screen 
          name="Home"
          component={HomeScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen 
          name="ManageMenu"
          component={ManageMenuScreen}
          options={{ 
            title: 'Manage Menu',
            headerStyle: {
              backgroundColor: '#FFFF00',
            },
            headerTintColor: '#000',
          }}
        />
        <Stack.Screen 
          name="MenuItemDetail"
          component={MenuItemDetailScreen}
          options={{ 
            title: 'Menu Item Details',
            headerStyle: {
              backgroundColor: '#FFFF00',
            },
            headerTintColor: '#000',
          }}
        />
        <Stack.Screen 
          name="MyMenu"
          component={MyMenuScreen}
          options={{ 
            title: 'My Menu',
            headerStyle: {
              backgroundColor: '#FFFF00',
            },
            headerTintColor: '#000',
          }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#FFFF00',
  },
  loginContainer: {
    flex: 1,
    backgroundColor: '#FFFF00',
  },
  loginScrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
  },
  headerImage: {
    width: '100%',
    height: 150,
    borderRadius: 10,
    marginBottom: 20,
  },
  loginImage: {
    width: '100%',
    height: 200,
    borderRadius: 10,
    marginBottom: 30,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
    textAlign: 'center',
  },
  loginTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginBottom: 20,
    textAlign: 'center',
  },
  loginSubtitle: {
    fontSize: 16,
    color: '#666',
    marginBottom: 30,
    textAlign: 'center',
  },
  menuScrollContainer: {
    flex: 1,
    width: '100%',
    marginTop: 10,
  },
  menuScrollContent: {
    paddingBottom: 30,
  },
  menuItemContainer: {
    marginBottom: 15,
  },
  menuItem: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    width: '100%',
  },
  menuItemName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  menuItemCourse: {
    fontSize: 14,
    color: '#000000',
    marginTop: 5,
  },
  menuItemDescription: {
    fontSize: 14,
    color: '#666',
    marginTop: 8,
    lineHeight: 20,
  },
  menuItemPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000000',
    marginTop: 10,
    textAlign: 'right',
  },
  emptyMessage: {
    textAlign: 'center',
    color: '#999',
    fontSize: 16,
    marginTop: 50,
  },
  formTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 20,
    textAlign: 'center',
  },
  label: {
    fontSize: 16,
    color: '#333',
    marginBottom: 8,
    fontWeight: '500',
  },
  input: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#ddd',
    fontSize: 16,
  },
  loginInput: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#ddd',
    fontSize: 16,
    color: '#333',
  },
  multilineInput: {
    minHeight: 100,
    textAlignVertical: 'top',
  },
  courseContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 20,
    justifyContent: 'space-between',
  },
  courseButton: {
    padding: 12,
    borderRadius: 8,
    backgroundColor: '#f0f0f0',
    marginBottom: 10,
    width: '48%',
    alignItems: 'center',
  },
  selectedCourseButton: {
    backgroundColor: '#000000',
  },
  courseText: {
    color: '#333',
  },
  selectedCourseText: {
    color: '#FFFF00',
    fontWeight: 'bold',
  },
  submitButtonContainer: {
    backgroundColor: '#000',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  submitButtonText: {
    color: '#FFFF00',
    fontSize: 16,
    fontWeight: 'bold',
  },
  menuOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.1)',
    zIndex: 99,
  },
  menuDropdown: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 60 : 50,
    right: 20,
    backgroundColor: '#FFFF00',
    borderRadius: 8,
    padding: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
    zIndex: 100,
    borderWidth: 1,
    borderColor: '#000000',
    minWidth: 150,
  },
  menuItemButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 15,
    width: '100%',
  },
  menuItemText: {
    fontSize: 16,
    color: '#000000',
    marginLeft: 10,
  },
  menuButton: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 50 : 20,
    right: 20,
    zIndex: 101,
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    borderRadius: 20,
    padding: 5,
  },
  loginButton: {
    backgroundColor: '#000000',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10,
  },
  loginButtonText: {
    color: '#FFFF00',
    fontSize: 16,
    fontWeight: 'bold',
  },
  loginHint: {
    marginTop: 20,
    color: '#999',
    textAlign: 'center',
    fontStyle: 'italic',
  },
  toggleAuthButton: {
    marginTop: 15,
    padding: 10,
    alignItems: 'center',
  },
  toggleAuthText: {
    color: '#000000',
    fontSize: 14,
    textDecorationLine: 'underline',
  },
  averagePricesContainer: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  averagePricesTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  averagePriceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 5,
  },
  averagePriceCourse: {
    fontSize: 14,
    color: '#666',
  },
  averagePriceValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000',
  },
  filterButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  filterButton: {
    backgroundColor: '#000',
    padding: 10,
    borderRadius: 8,
    flex: 1,
    marginRight: 10,
  },
  filterButtonText: {
    color: '#FFFF00',
    textAlign: 'center',
  },
  clearFilterButton: {
    backgroundColor: '#ccc',
    padding: 10,
    borderRadius: 8,
  },
  clearFilterButtonText: {
    color: '#000',
    textAlign: 'center',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    backgroundColor: '#FFFF00',
    padding: 20,
    borderRadius: 10,
    width: '80%',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
  },
  modalFilterOption: {
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  modalFilterText: {
    fontSize: 16,
    textAlign: 'center',
  },
  modalCloseButton: {
    marginTop: 15,
    padding: 10,
  },
  modalCloseText: {
    fontSize: 16,
    color: '#000',
    textAlign: 'center',
    textDecorationLine: 'underline',
  },
  manageContainer: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: '#FFFF00',
  },
  manageFormContainer: {
    flex: 1,
    padding: 20,
    borderRightWidth: 1,
    borderRightColor: '#ddd',
  },
  menuListContainer: {
    flex: 1,
    padding: 20,
  },
  currentMenuTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
  },
  manageMenuItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
  },
  manageMenuItemInfo: {
    flex: 1,
  },
  manageMenuItemName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  manageMenuItemCourse: {
    fontSize: 14,
    color: '#666',
  },
  manageMenuItemPrice: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  manageMenuItemActions: {
    flexDirection: 'row',
  },
  editButton: {
    backgroundColor: '#000',
    padding: 8,
    borderRadius: 5,
    marginRight: 5,
  },
  deleteButton: {
    backgroundColor: '#ff4444',
    padding: 8,
    borderRadius: 5,
  },
  detailContainer: {
    flex: 1,
    padding: 20,
    backgroundColor: '#FFFF00',
  },
  detailTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  detailCourse: {
    fontSize: 18,
    color: '#000',
    marginBottom: 15,
  },
  detailDescription: {
    fontSize: 16,
    lineHeight: 24,
    marginBottom: 20,
  },
  detailPrice: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  myMenuItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
  },
  myMenuItemInfo: {
    flex: 1,
  },
  myMenuItemName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  myMenuItemCourse: {
    fontSize: 14,
    color: '#666',
  },
  myMenuItemPrice: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  removeButton: {
    marginLeft: 10,
  },
  addToMenuButton: {
    backgroundColor: '#000',
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  addToMenuButtonText: {
    color: '#FFFF00',
    fontSize: 14,
  },
  totalContainer: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  totalText: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#000',
  },
});

export default App;